/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;
/**
 *
 * @author Sophia
 */
public class ManageCheckBook {
    Scanner sc = new Scanner(System.in);
	
	public ManageCheckBook() {
		// TODO Auto-generated constructor stub
	}
	
	//check out
	public void checkOutBook() throws InterruptedException {
		int bcnt = 0;
		int mcnt = 0;
		
		ChkBook ckb = new ChkBook();
		System.out.println("Enter book number:");
		String bookno = sc.nextLine();
		System.out.println("Enter Member ID:");			
		String memid = sc.nextLine();
		System.out.println("Enter Member Password:");			
		String mempwd = sc.nextLine();
		
		//verify book info 
		for(int i=0;i<Books.bList.size();i++){
			if (bookno.equals(Books.bList.get(i).getbNo())){
				bcnt++;
				ckb.setbNo(bookno);
				ckb.setbGenre(Books.bList.get(i).getbGenre());
				break;
			} //end if
		}//end for
		
		//verify member info
		for(int i=0;i<Members.memList.size();i++){
			if (memid.equals(Members.memList.get(i).getmId()) && mempwd.equals(Members.memList.get(i).getmPwd())){
				mcnt++;
				ckb.setmId(memid);
				break;
			} //end if
		}//end for		
		
		if (bcnt== 0 || mcnt == 0){
			System.out.println("Wrong !!. Please re-enter the book number/Id/Password\n\n");
		}else{
			//check in process
			ckb.setckType("check-out");
			LocalDate now = LocalDate.now();
			ckb.setckOutDate(now.toString());
			ckb.setckInDate("-");
			ChkBook.trbList.add(ckb);
			System.out.println("Successfully Check-out this Book \n\n");
		}
		Thread.sleep(1000);
		Menus mn = new Menus();
		mn.doCheckMenu();
	}
	
	//check in
	public void checkInBook() throws InterruptedException {
		int bcnt = 0;
		int mcnt = 0;
		
		System.out.println("Enter book number:");
		String bookno = sc.nextLine();
		System.out.println("Enter Member ID:");			
		String memid = sc.nextLine();
		System.out.println("Enter Member Password:");			
		String mempwd = sc.nextLine();
		
		for(int i=0;i<Books.bList.size();i++){
			if (bookno.equals(Books.bList.get(i).getbNo())){
				bcnt++;
				break;
			} //end if
		}//end for
		
		for(int i=0;i<Members.memList.size();i++){
			if (memid.equals(Members.memList.get(i).getmId()) && mempwd.equals(Members.memList.get(i).getmPwd())){
				mcnt++;				
				break;
			} //end if
		}//end for
		
		
		if (bcnt== 0 || mcnt == 0){
			System.out.println("Wrong !!. Please re-enter the book number/Id/Password\n\n");
		}else{
			//check out process
			LocalDate  now = LocalDate.now();
			for(int i=0;i<ChkBook.trbList.size();i++){
				if (bookno.equals(ChkBook.trbList.get(i).getbNo())){
					
					//compute diff day (day1, day2)
					String day1 = ChkBook.trbList.get(i).getckOutDate();
					String day2 = "2023-11-10"; //now.toString();
					Period days = Period.between(LocalDate.parse(day1), LocalDate.parse(day2));
					int dayCnt = days.getDays();
					ChkBook.trbList.get(i).setckType("check-in");
					ChkBook.trbList.get(i).setckInDate(day2);
					ChkBook.trbList.get(i).setholdDays(dayCnt);
					
					//compute Late Fines
					if (days.getDays() > ChkBook.HOLD_PERIOD){
						int price = (days.getDays() -ChkBook.HOLD_PERIOD) * ChkBook.FINES_PER_DAY;
						ChkBook.trbList.get(i).setfines(price);
					}
					System.out.println("Successfully Check-In this Book \n\n");
					break;
				} //end if
			}//end for		
		}
		Thread.sleep(1000);
		Menus mn = new Menus();
		mn.doCheckMenu();
	}	
	
	//display borrowed lists of books
	public void borrowList() throws InterruptedException {
		System.out.println("======= borrowed lists of books =======\n");
		//System.out.println("Book No\t|\t Gener\t|\t Id\t|\t Type\t|\tCheckOut Date\t|\tCheckIn Date\t|\t Holded Days\t|\t Fines\t\n");
		System.out.printf("%10s |","Book No");		
		System.out.printf("%10s |","Book Gener");
		System.out.printf("%10s |","Mem Id");
		System.out.printf("%10s |","Type");
		System.out.printf("%15s |","CheckOut Date");
		System.out.printf("%15s |","CheckIn Date");
		System.out.printf("%-10s |","Holded Days");
		System.out.printf("%-10s |%n","Fines Amt");
		 for (int i = 0; i < ChkBook.trbList.size(); i++) {			
			System.out.println("=======================================\n");
                        System.out.printf("%10s |",ChkBook.trbList.get(i).getbNo());
                        System.out.printf("%10s |",ChkBook.trbList.get(i).getbGenre());
                        System.out.printf("%10s |", ChkBook.trbList.get(i).getmId());
                        System.out.printf("%10s |",ChkBook.trbList.get(i).getckType());
                        System.out.printf("%15s |",ChkBook.trbList.get(i).getckOutDate());
                        System.out.printf("%15s |",ChkBook.trbList.get(i).getckInDate());
                        System.out.printf("%10d |",ChkBook.trbList.get(i).getholdDays());
                        System.out.printf("%10d |%n",ChkBook.trbList.get(i).getfines());
                        System.out.println("=======================================\n");
                 } // end for
    }
}
