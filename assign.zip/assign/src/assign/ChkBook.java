/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign;
import java.util.ArrayList;
/**
 *
 * @author Sophia
 */
public class ChkBook {	
	
	public static final int HOLD_PERIOD = 7;
	public static final int FINES_PER_DAY = 20;
	
	private String mId;
	private String bNo;
	private String bGenre;	
	private String ckType;
	private String ckOutDate;
	private String ckInDate;
	private int holdDays = 0;
	private int fines = 0;
	
	
	public static ArrayList<ChkBook> trbList = new ArrayList<ChkBook>();
	
	public ChkBook() {
		// TODO Auto-generated constructor stub
	}
	

	//getter
	public String getmId(){
		return mId;
	}
	
	public String getbNo(){
		return bNo;
	}

	public String getbGenre(){
		return bGenre;
	}

	public String getckType(){
		return ckType;
	}
	
	public String getckInDate(){
		return ckInDate;
	}
	
	public String getckOutDate(){
		return ckOutDate;
	}
	
	public int getholdDays(){
		return holdDays;
	}
	
	public int getfines(){
		return fines;
	}

	//setter	
	public void setmId(String id){
		this.mId = id;
	}
	
	public void setbNo(String no){
		this.bNo = no;
	}	
	
	public void setbGenre(String genre){
		this.bGenre = genre;
	}
	
	public void setckType(String type){
		this.ckType = type;
	}
	
	public void setckInDate(String date){
		this.ckInDate = date;
	}
	
	public void setckOutDate(String date){
		this.ckOutDate = date;
	}
	
	public void setholdDays(int days){
		this.holdDays = days;
	}	
	public void setfines(int price){
		this.fines = price;
	}
}

