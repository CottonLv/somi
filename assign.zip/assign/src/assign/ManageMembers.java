/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign;
import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author Sophia
 */
public class ManageMembers {
    Scanner sc = new Scanner(System.in);
	public ManageMembers() {
		// TODO Auto-generated constructor stub
	}
	
	public void registMember() throws InterruptedException {
		Members mem = new Members();		
		
		int cnt = 0;
		System.out.println("Enter Member's Id:");
		String memId = sc.nextLine();
		
		for(int i=0;i< Members.memList.size();i++){
			if (memId.equals(Members.memList.get(i).getmId())){
				cnt++;
				System.out.println("Duplicate Member's Id!! re-enter:");
				break;
			} //end if
		}//end for
		
		if (cnt==0){  //if new member
			mem.setmId(memId);		
		
			System.out.println("Please enter Member's Password :");
			String pwd = sc.nextLine();
			mem.setmPwd(pwd);
					
			System.out.println("Please enter Member's name :");
			String name = sc.nextLine();
			mem.setmName(name);
			
			System.out.println("Please enter Member' email:");
			String email = sc.nextLine();
			mem.setmEail(email);
			
			System.out.println("Please enter Member' cellphone number:");
			String telno = sc.nextLine();
			mem.setmTelno(telno);
			
			System.out.println("Please enter Member' age:");
			String age = sc.nextLine();
			mem.setmAge(age);
			
			LocalDate  now = LocalDate.now();
			mem.setmRegDate(now.toString());		
	
			
			//preview Member info
			System.out.println("Member's Id : " + mem.getmId());
	        System.out.println("Member's Pwd : " + mem.getmId());
	        System.out.println("Member's Name : " + mem.getmName());
	        System.out.println("Member's email : " + mem.getmEmail());
	        System.out.println("Member's Cellphone Number : " + mem.getmTelno());
	        System.out.println("Member's Age : " + mem.getmAge());
	        System.out.println("Member's Regist Date : " + mem.getmRegDate());        
        
	        System.out.println("Would you like to register this member? y or n?");
            String regYN = sc.nextLine();
		
	        if (regYN.equalsIgnoreCase("y")){
	        	Members.memList.add(mem);
	           	System.out.println("Success Registration !!!");
	
	        }else{
	        	System.out.println("Cancel Registration !!!");	
	        }
		}
    Thread.sleep(1000);
    Menus mn = new Menus();
    mn.doMemberMenu();            	
	}
	
	
	
	public void totalMemberList() throws InterruptedException{		
		 int cnt = 0;
		 for (int i = 0; i < Members.memList.size(); i++) {
	        System.out.println("++++++++++++++++++++++++++++++++");
	        System.out.println("Member's Id : " + Members.memList.get(i).getmId());
	        System.out.println("Member's Pwd : " + Members.memList.get(i).getmPwd());
	        System.out.println("Member's Name : " + Members.memList.get(i).getmName());
	        System.out.println("Member's email : " + Members.memList.get(i).getmEmail());
	        System.out.println("Member's Cellphone Number : " + Members.memList.get(i).getmTelno());
	        System.out.println("Member's Age : " + Members.memList.get(i).getmAge());
	        System.out.println("Member's Regist Date : " + Members.memList.get(i).getmRegDate()); 
	        System.out.println("++++++++++++++++++++++++++++++++\n");
	        cnt++;
	     } // end for
		 
		   if (cnt == 0) {
			   System.out.println("++++++++++++++++++++++++++++++++");
	           System.out.println("member : no data ");
	           System.out.println("++++++++++++++++++++++++++++++++\n\n");
	       }
		   
		Thread.sleep(1000);
       	Menus mn = new Menus();
        mn.doMemberMenu();      
	}
	
	public void searchMember() throws InterruptedException {
	
		System.out.println("Enter Member ID:");			
		String memid = sc.nextLine();
		System.out.println("Enter Member Password:");			
		String mempwd = sc.nextLine();
		
		int cnt = 0;
        for (int i = 0; i < Members.memList.size(); i++) {
            if (memid.equals(Members.memList.get(i).getmId()) && mempwd.equals(Members.memList.get(i).getmPwd())) {
            	System.out.println("++++++++++++++++++++++++++++++++");
                System.out.println("Member's Id : " + Members.memList.get(i).getmId());
     	        System.out.println("Member's Pwd : " + Members.memList.get(i).getmPwd());
     	        System.out.println("Member's Name : " + Members.memList.get(i).getmName());
     	        System.out.println("Member's email : " + Members.memList.get(i).getmEmail());
     	        System.out.println("Member's Cellphone Number : " + Members.memList.get(i).getmTelno());
     	        System.out.println("Member's Age : " + Members.memList.get(i).getmAge());
     	        System.out.println("Member's Regist Date : " + Members.memList.get(i).getmRegDate()); 
                System.out.println("++++++++++++++++++++++++++++++++\n");
                cnt++;
                break;
            }
        } // end for
        if (cnt == 0) {
            System.out.println("This member does not exist. Please re-enter another memeber's id and memeber'spassword.\n\n");
        } 
        Thread.sleep(1000);
    	Menus mn = new Menus();
       	mn.doMemberMenu(); 
	}
	
	public void modifyMember() throws InterruptedException {
		System.out.println("To modify infomation, Enter Member ID:");			
		String memid = sc.nextLine();
		System.out.println("Enter Member Password:");			
		String mempwd = sc.nextLine();
        int cnt = 0;
        for (int i = 0; i < Members.memList.size(); i++) {
        	if (memid.equals(Members.memList.get(i).getmId()) && mempwd.equals(Members.memList.get(i).getmPwd())) {            	

        		System.out.println("Please enter Member's name :");
    			String name = sc.nextLine();
    			Members.memList.get(i).setmName(name);
    			
    			
    			System.out.println("Please enter Member' email:");
    			String email = sc.nextLine();
    			Members.memList.get(i).setmEail(email);
            			
    			System.out.println("Please enter Member' cellphone number:");
    			String telno = sc.nextLine();
    			Members.memList.get(i).setmTelno(telno);
    			        			
    			System.out.println("Please enter Member' age:");
    			String age = sc.nextLine();	
    			Members.memList.get(i).setmAge(age);
                   			
                cnt++;
                System.out.println("Modify Successfully ");
                Menus mn = new Menus();
	           	mn.doMemberMenu();
                break;
            }
        } // end for
        if (cnt == 0) {
        	System.out.println("This member does not exist. Please re-enter another memeber's id and memeber'spassword.\n\n");
        } 
        Thread.sleep(1000);
    	Menus mn = new Menus();
       	mn.doMemberMenu();                
	}
	
	public void deleteMember() throws InterruptedException {
		
		System.out.println("To modify infomation, Enter Member ID:");			
		String memid = sc.nextLine();
		System.out.println("Enter Member Password:");			
		String mempwd = sc.nextLine();
        int cnt = 0;
        for (int i = 0; i < Members.memList.size(); i++) {
        	if (memid.equals(Members.memList.get(i).getmId()) && mempwd.equals(Members.memList.get(i).getmPwd())) { 
        		Members.memList.remove(i);
                cnt++;
                System.out.println("Delete Successfully");
                Menus mn = new Menus();
	           	mn.doMemberMenu(); 
                break;
                }
            } // end for
            if (cnt == 0) {
            	System.out.println("This member does not exist. Please re-enter another memeber's id and memeber'spassword.\n\n");
            }
        Thread.sleep(1000);
    	Menus mn = new Menus();
       	mn.doMemberMenu(); 
	}
}
