/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lec203assign;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

/**
 *
 * @author Gumin
 */
public class MedicalConsole {
    //Create HealthService 
    private static HealthService hs = new HealthService("HELP HealthService");
    private static Scanner sc = new Scanner(System.in);
    private static boolean isFinished = true;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here        
        MedicalConsole mc = new MedicalConsole();
        //install data
        mc.toSetupData();
        
        while(isFinished){
            mc.displayMenu();
        }
    }
    //install data
    public void toSetupData(){
        //install Some Sample Patients
        Patient pat1 = new Patient("John",true);
        Patient pat2 = new Patient("Rucy",false);
        Patient pat3 = new Patient("Tom",true);
           
        //install some Hospitals
        Hospital hp1 = new Hospital("hp1",0.3);
        Hospital hp2 = new Hospital("hp2",0.7);
        
        //insatall some Clinics
        Clinic cn1 = new Clinic("cn1",10.0,20.0);
        Clinic cn2 = new Clinic("cn2",5.0,10.0);     
        
        //install procedure
        Procedure pd1 = new Procedure("pd1","pd1_desc",true,10.5);
        Procedure pd2 = new Procedure("pd1","pd1_desc",true,20.0);
        Procedure pd3 = new Procedure("pd1","pd1_desc",true,30.1);
        
        hs.addPatient(pat1);
        hs.addPatient(pat2);
        hs.addPatient(pat3);
        
        hs.addMedicalFacility(hp1);
        hs.addMedicalFacility(hp2);
        hs.addMedicalFacility(cn1);
        hs.addMedicalFacility(cn2);
        
        hp1.addProcedure(pd1);
        hp1.addProcedure(pd2);
        hp2.addProcedure(pd1);
        hp2.addProcedure(pd3);
    }
    
    public void displayMenu(){
        System.out.println("********************** Welcom to the HealthService Menu  **********************");
	System.out.println("Add an Object >>>>>>>\t[1] Patient\t [2] MedicalFacility\t[3]Procedure");	
        System.out.println("List Objects >>>>>>>>\t[5] Patient\t [6] MedicalFacility");
        System.out.println("Delete an Objects >>>\t[10]Patient\t [11]MedicalFacility");
        System.out.println("Visit >>>>>>>>>>>>>>>\t[15]Patient & MedicalFacility");
        System.out.println("EXIT >>>>>>>>>>>>>>>>\t[0] exit");
	System.out.println("*******************************************************************************\n");
        System.out.print("Enter MENU number:");
       
        String MenuNo = sc.nextLine();
       		
        switch(MenuNo){
            case("1"):
                createPatient();		        	
                break;				
            case("2"):
                createMedicalFacility();
                break;        
            case("3"):
                createProcedure();
                break;	
            case("5"):
                listOfPatients();
                break;	
            case("6"):
                listOfMedicalFacilities("A");
                break;
            case("10"):
                deletePatient();
                break;
            case("11"):
                deleteMedicalFacility();
                break;
            case("15"):
                visitPatientAndMedicalFacility();
                break;
            case("0"):
                System.out.println("***** Good Bye!! See You Again *****\n\n");
                sc.close();
                System.exit(0);
                break;
            default:
                System.out.println("Your Entered wrong Menu!! Enter Again\n\n");                
                break;
        }
    } 
    
    public void createPatient(){
        boolean isPrivate = true;
        System.out.print("Input A Patient' Name :");
        String patName =  sc.nextLine();
        System.out.print("Choose private(T) or public(F), then input T or F :");
        String strPrivate =  sc.nextLine();
        if (strPrivate.equalsIgnoreCase("T")){
            isPrivate = true;
        }else if (strPrivate.equalsIgnoreCase("F")){
            isPrivate = false;
        }else{
            strPrivate = null;
        }           
        if (strPrivate != null){
            Patient pat = new Patient(patName,isPrivate);
            hs.addPatient(pat);
            System.out.println("Successfully Add A New Patient \n\n");
        }else{
            System.out.println("You entered Wrong Value !! Goto Menu then Again \n\n");
        }
    }
    
    public void createMedicalFacility(){      
        System.out.print("Choose type of MedicalFacility, input H(hospital) or C(clinic) :");
        String mfType =  sc.nextLine();
                
        String mfName = "";
        if (mfType.equalsIgnoreCase("C")){
            System.out.print("Input Name of the Clinic :");
            mfName =  sc.nextLine();
            System.out.print("Input Fee of the Clinic :");
            double mfFee = sc.nextDouble();
            sc.nextLine();
            System.out.print("Input gapPercent of the Clinic :");
            double mfgapPercent = sc.nextDouble();
            sc.nextLine();
            Clinic cn = new Clinic(mfName,mfFee,mfgapPercent);
            hs.addMedicalFacility(cn);
            System.out.println("Successfully Add A New Clinic \n\n");
        }else if(mfType.equalsIgnoreCase("H")){
            System.out.print("Input Name of the Hospital :");
            mfName =  sc.nextLine();
            System.out.print("Input Probability of the Hospital (between 0 to 1) :");
            double mfprodAdmit = sc.nextDouble();
            sc.nextLine();
            if (mfprodAdmit > 0 && mfprodAdmit < 1 ){
                Hospital hp = new Hospital(mfName,mfprodAdmit);
                hs.addMedicalFacility(hp);
                System.out.println("Successfully Add A New Hospital \n\n");
            }else{
                System.out.println("You entered Wrong Value !! Goto Menu then Again \n\n");
            }
        }else{
            System.out.println("You entered Wrong Value !! Goto Menu then Again \n\n");
        }
    }    
    
    public boolean createProcedure(){ 
        //check hospital list
        boolean isExistedHs = hs.getMflist().stream()
                                            .anyMatch(m -> m instanceof Hospital);
        
        Hospital hp = null;              
        if (!isExistedHs){
            System.out.println("There are no Hospitals !! You should add one, Goto Menu then Again \n\n");
            return false;
        }else{
            listOfMedicalFacilities("H");
            System.out.print("Choose one of the Hospitals, then Input Id of A Hospital : ");
            int inputHpId = sc.nextInt();
            sc.nextLine();
            
            Optional<MedicalFacility> existedMf = hs.getMflist().stream()
                                                                .filter(m -> m instanceof Hospital)
                                                                .filter(m -> m.getMfId() == inputHpId)
                                                                .findFirst();
            if (!existedMf.isPresent()){
               System.out.println("Id of Hospital is not Found!! Goto Menu then Again \n\n");
                return false;
            }  
            
            hp = (Hospital)existedMf.get();
        }
                                            
        
        System.out.print("Input Name of the Procedure :");
        String pdName =  sc.nextLine();

        System.out.print("Input Description of the Procedure :");
        String pdDesc = sc.nextLine();

        System.out.print("Choose Elective(T) or Not Elective(F), Then input T or F :");
        String strElective =  sc.nextLine();
        
        boolean isElective = true;
        if (strElective.equalsIgnoreCase("T")){
            isElective = true;
        }else if(strElective.equalsIgnoreCase("F")){
            isElective = false;
        }else{
            strElective = null;
        }
        if (strElective != null){
            System.out.print("Input Cost of this procedure :");
            double pdCost = sc.nextDouble();
            sc.nextLine();
            Procedure pd = new Procedure(pdName,pdDesc,isElective,pdCost); 
            hp.addProcedure(pd);
            System.out.println("Successfully Add A New Procedure \n\n");
            return true;
        }else{  
            System.out.println("You entered Wrong Value !! Goto Menu then Again \n\n");
            return false;
        }
    }
    
    public void listOfPatients(){
        System.out.println("\n========== List of Patients ===========");
        hs.getPatlist().stream()                     
                       .forEach(s -> System.out.println(s.toString()));
        System.out.println("=======================================\n");
    }
    
    
    public void listOfMedicalFacilities(String mfType){
        if (mfType.equalsIgnoreCase("A")){
            System.out.print("Choose type of MedicalFacility, input H(hospital) or C(clinic) :");
            mfType =  sc.nextLine();
        }
        if (mfType.equalsIgnoreCase("C")){ 
            System.out.println("\n========== List of Clinics  ===========");
            hs.getMflist().stream()
                           .filter(s -> s instanceof Clinic )
                           .forEach(s -> System.out.println(s.toString()));
            System.out.println("=========================================\n");  
        }else if(mfType.equalsIgnoreCase("H")){
            System.out.println("\n========== List of Hospitals  ===========");
            hs.getMflist().stream()
                           .filter(s -> s instanceof Hospital )
                           .forEach(s -> System.out.println(s.toString()));
            System.out.println("=========================================\n");  
        }else{
            System.out.println("You entered Wrong Value !! Goto Menu then Again \n\n");
        }
    }
    
    
    public boolean deletePatient(){       
        System.out.print("Input Patient'id  to delete :");
        int patId =  sc.nextInt();
        sc.nextLine();
        //check valid 
        Optional<Patient> existedPat = hs.getPatlist().stream()
                                                      .filter(p -> p.getPatId() == patId)
                                                      .findFirst();
        if (!existedPat.isPresent()){
            System.out.println("Id of the patient is not Found!! Goto Menu then Again \n\n");
            return false;
        }
        //detail object
        System.out.println("==================Patient Info to delete==================");
        System.out.println(existedPat.toString());
        System.out.println("==========================================================");
        //confirm to delete
        System.out.print("do you still wish to delete it? input Yes(y) or No (n) : ");
        String isDelete = sc.nextLine();
         if (isDelete.equalsIgnoreCase("Y")){
                hs.getPatlist().removeIf(p -> p.getPatId() == patId );                         
                System.out.println("Successfully Delete this Patient");
                return true;
            }else{
                System.out.println("This Patient didnot delete, Goto Menu then Again");
                return false;
           }        
    }
    
    public boolean deleteMedicalFacility(){
        System.out.print("Choose type of MedicalFacility, input H(hospital) or C(clinic) :");
        String mfType =  sc.nextLine();
        
        if (mfType.equalsIgnoreCase("C")){
            System.out.print("Input Id of the Clinic to delete :");
            int mfId =  sc.nextInt();
            sc.nextLine();
            //check valid clinic id 
            Optional<MedicalFacility> existedCn = hs.getMflist().stream()
                                                                 .filter(m-> m instanceof Clinic)
                                                                 .filter(m -> m.getMfId() == mfId)
                                                                .findFirst();
           
            if (!existedCn.isPresent()){
                System.out.println("Id of the Clinic is not Found!! Goto Menu then Again \n\n");
                return false;
            }
             //detail object
            Clinic cn = (Clinic)existedCn.get();
            System.out.println("==================Clinic Info to delete==================");
            System.out.println(cn.toString());
            System.out.println("==========================================================");
            //confirm to delete
            System.out.print("do you still wish to delete it? input Yes(y) or No (n) : ");
            String isDelete = sc.nextLine();
            if (isDelete.equalsIgnoreCase("Y")){
                hs.getMflist().removeIf(m -> m.getMfId() == mfId);                  
                System.out.println("Successfully Delete this Hospital");
                return true;
            }else{
                System.out.println("This Hospital didnot delete, Goto Menu then Again");
                return false;
           }
        }else if(mfType.equalsIgnoreCase("H")){
             System.out.print("Input Id of the Hospital to delete :");
            int mfId =  sc.nextInt();
            sc.nextLine();
             //check valid hospital id 
            Optional<MedicalFacility> existedMf = hs.getMflist().stream()
                                                                .filter(m -> m instanceof Hospital)
                                                                .filter(m -> m.getMfId() == mfId)
                                                                .findFirst();
            if (!existedMf.isPresent()){
                System.out.println("Id of the Hospital is not Found!! Goto Menu then Again \n\n");
                return false;
            } 
            
            
            Hospital hp = (Hospital)existedMf.get();
            //detail object
            System.out.println("==================Hospital Info to delete==================");
            System.out.println(hp.toString());
            System.out.println("===========================================================");
            
            //confirm to delete
            int pdcnt = hp.getPdlists().size();
            if (pdcnt > 0){
                System.out.print("This Hospital can perform " + pdcnt + " procedures -");
            }
           
            System.out.print("do you still wish to delete it? input Yes(y) or No (n) : ");
            String isDelete = sc.nextLine();
            if (isDelete.equalsIgnoreCase("Y")){
                hs.getMflist().removeIf(m -> m.getMfId() == mfId);                  
                System.out.println("Successfully Delete this Hospital");
                return true;
            }else{
                System.out.println("This Hospital didnot delete, Goto Menu then Again");
                return false;
           }
        }else{
            System.out.println("You entered Wrong Value !! Goto Menu then Again \n\n");
            return false;
        }  
    }
     
     
     public boolean visitPatientAndMedicalFacility(){
        System.out.print("Input Patient'id  to visit :");
        int patId =  sc.nextInt();
        sc.nextLine();
        //check invalid patient id
        Optional<Patient> existedPat = hs.getPatlist().stream()      
                                                      .filter(p ->  p.getPatId() == patId)
                                                      .findFirst();
                                    
        if (!existedPat.isPresent()){
             System.out.println("Patient'id is Not Found  !! Goto Menu then Again \n\n");
             return false;
        }                           
        Patient vistedPat = existedPat.get();
        
        System.out.print("Input Id of MedicalFacility to visit :");
        int mfId =  sc.nextInt();
        sc.nextLine();
        //check invalid MedicalFacility id
        Optional<MedicalFacility> existedMf = hs.getMflist().stream()      
                                                            .filter(m -> m.getMfId() == mfId)
                                                            .findFirst();
        if (!existedMf.isPresent()){
             System.out.println("Id of MedicalFacility is Not Found  !! Goto Menu then Again \n\n");
             return false;
        }         
        MedicalFacility vistedMf = existedMf.get();        
        
        if(vistedMf instanceof Hospital){
            Hospital hp = (Hospital) vistedMf;
            return hp.visit(vistedPat);
        }else if (vistedMf instanceof Clinic){
            Clinic cn = (Clinic) vistedMf;
            return cn.visit(vistedPat);
         }                  
         return true;
    }
    
}
