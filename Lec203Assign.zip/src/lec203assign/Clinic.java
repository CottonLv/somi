/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lec203assign;

/**
 *
 * @author Gumin
 */
public class Clinic extends MedicalFacility {
    private double fee;
    private double gapPercent;

    public Clinic(String fname,double fee, double gapPercent) {
        super(fname);
        this.fee = fee;
        this.gapPercent = gapPercent;
    }
    
    @Override
    public boolean visit(Patient pat){
        double cost = 0.0;
        if(pat.getCurrentFacility() != this){
            pat.setCurrentFacility(this);
            return false;
            //A consultation cannt be done
        }else{
            //A patient receive a consultation
            if (pat.getIsPrivate()){
                cost = this.fee;
            }else{
                cost = this.fee * this.gapPercent * 0.01;
            }
            pat.addBalance(cost);            
        }
        return true;
    }

    @Override
    public String toString() {
        return "Clinic INFO {Id of the Clinic : " + super.getMfId() + ", Name of the Clinic : " +  super.getMfName() + ", fee of the Clinic : " + fee + ", gapPercent of the Clinic=" + gapPercent + "}";
    }
}
