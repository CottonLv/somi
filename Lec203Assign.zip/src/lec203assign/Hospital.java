/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lec203assign;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Gumin
 */
public class Hospital extends MedicalFacility{
    
    private List<Procedure> pdlists;
    private double prodAdmit; //between 0 and 1

    public Hospital(String fname,double prodAdmint) {
        super(fname);
        this.prodAdmit = prodAdmint;
        this.pdlists = new ArrayList<Procedure>();
    }
    
    @Override
    public boolean visit(Patient pat){
        Scanner sc = new Scanner(System.in);
        Random ran = new Random();
        double ranNum = ran.nextDouble();
        
        if (ranNum > this.prodAdmit){
          
            pat.setCurrentFacility(this);
            //choose procedure
            System.out.println("\n========== List of Procedure ===========");
            pdlists.forEach(pd -> System.out.println(pd.toString()));
            System.out.println("===========================================");
            System.out.println("This patient is admitted!!");
            System.out.print("Input Name of Procedure to performed :");
            String pdNm = sc.nextLine();
            Procedure selpd = selectProcedure(pdNm);
            if (selpd == null){
                System.out.println("Id of the Procedure is not Found!! Goto Menu then Again \n\n");
                return false;
            } 
            double patCost =  computeCost(pat,selpd);
            pat.addBalance(patCost);
            return true;
        }
        System.out.println("This patient is not admitted!! Goto Menu then Again \n\n");
        return false;        
    }
    
    public void addProcedure(Procedure pd){
        pdlists.add(pd);
    }

    public double computeCost(Patient pat, Procedure pd){
        double pdcost = 0.0;
        if (pat.getIsPrivate() && pd.getIsElective()){
            pdcost = 1000;
        }else if(pat.getIsPrivate() && !pd.getIsElective()){
            pdcost = 2000;
        }else if(!pat.getIsPrivate() && pd.getIsElective()){
            pdcost = pd.getCost();
        }else{
            pdcost = 0;
        }
        return pdcost;
    }
    
    public Procedure selectProcedure(String pdName){
        for(Procedure p : pdlists){
            if (p.getPdName().equals(pdName))
                return p;
        }
        return null;
    }
    
    public List<Procedure> getPdlists(){
        return pdlists;
    }
    
    @Override
    public String toString() {
        return "Hospital INFO {Id of Hospital : " + super.getMfId() + ", Name of the Hospital : " + super.getMfName() + ", Id of the Hospital : " + super.getMfId() + ", ProdAdmit of the Hospital: " + prodAdmit + ", Procedure List : " + pdlists + "}";
    
    }
    
    
}
