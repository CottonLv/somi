/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lec203assign;

/**
 *
 * @author Gumin
 */
public abstract class MedicalFacility {
    private int mfId;
    private String mfName;
    private static int MFCNT = 100;
    
    public abstract boolean visit(Patient pat);
    
    public MedicalFacility(String fname){
        MFCNT++;
        this.mfId = MFCNT;
        this.mfName = fname;
    }
    
    public int getMfId() {
        return mfId;
    }
    
    public String getMfName() {
        return mfName;
    }

    public void setMfName(String mfName) {
        this.mfName = mfName;
    }
    
   @Override
    public String toString() {
        return "INFO of MedicalFacility{" + "Id of the MedicalFacility : " + mfId + ", Name of the MedicalFacility : " + mfName + '}';
    }
}
