/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lec203assign;

/**
 *
 * @author Gumin
 */
public class Procedure {
    private int pdId;
    private String pdName;
    private String pdDesc;
    private boolean isElective;
    private double cost;
    private static int PDCNT = 200;
    
    public Procedure(String pdName, String pdDesc,boolean isElective,double cost){
        PDCNT++;
        this.pdId = PDCNT;
        this.pdName = pdName;
        this.pdDesc= pdDesc;
        this.isElective = isElective;
        this.cost = cost;        
    }

    public int getPdId() {
        return pdId;
    }

    public String getPdName() {
        return pdName;
    }

    public void setPdName(String pdName) {
        this.pdName = pdName;
    }

    public String getPdDesc() {
        return pdDesc;
    }

    public void setPdDesc(String pdDesc) {
        this.pdDesc = pdDesc;
    }

    public boolean getIsElective() {
        return isElective;
    }

    public void setIsElective(boolean isElective) {
        this.isElective = isElective;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
    

    @Override
    public String toString() {
        return "Procedure{" + "pdId=" + pdId + ", pdName=" + pdName + ", pdDesc=" + pdDesc + ", isElective=" + isElective + ", cost=" + cost + '}';
    }
    
}
