/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lec203assign;

/**
 *
 * @author Gumin
 */
public class Patient {    
    private int patId;
    private String patName;
    private boolean isPrivate;
    private double balance;
    private MedicalFacility currentFacility;
    private static int PATCNT = 1000;
    
    public Patient(){
        
    }
    
    public Patient(String name, boolean isPrivate){
        PATCNT++;
        this.patId = PATCNT;
        this.patName = name;
        this.isPrivate = isPrivate;
        this.balance = 0.0;        
    }

    public int getPatId() {
        return patId;
    }

    public String getPatName() {
        return patName;
    }

    public void setPatName(String patName) {
        this.patName = patName;
    }

    public boolean getIsPrivate() {
        return isPrivate;
    }

    public void setIsPrivate(boolean isPrivate) {
        this.isPrivate = isPrivate;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public MedicalFacility getCurrentFacility() {
        return currentFacility;
    }

    public void setCurrentFacility(MedicalFacility currentFacility) {
        this.currentFacility = currentFacility;
    }
    
    public void addBalance(double cost){
        this.balance = this.balance + cost;
    }

    @Override
    public String toString() {
        return "Patient INFO {" + "The Patient'Id : " + patId + " , The patient's Name : " + patName + ", isPrivate : " + isPrivate + ", Balance of the patient  : " + balance + ", currentFacility info : " + currentFacility + '}';
    }
    
    
}
