/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lec203assign;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gumin
 */
public class HealthService {
    private String hsName;
    private List<Patient> patlist;
    private List<MedicalFacility> mflist;
    
    public HealthService(String hsName){
        this.hsName = hsName;
        patlist = new ArrayList<Patient>();
        mflist = new ArrayList<MedicalFacility>();
    }

    public String getHsName() {
        return hsName;
    }

    public void setHsName(String hsName) {
        this.hsName = hsName;
    }

    public List<Patient> getPatlist() {
        return patlist;
    }

      public List<MedicalFacility> getMflist() {
        return mflist;
    }

   public void addPatient(Patient p){
       patlist.add(p);
   }
   
   public boolean addMedicalFacility(MedicalFacility mf){
       if (mf == null)
           return false;
       
       if (mf instanceof Hospital){
           Hospital hospital = (Hospital)mf;
           mflist.add(hospital);
           return true;
       }else{
           Clinic clinic = (Clinic)mf;
           mflist.add(clinic);
           return true;
       }
   }

    @Override
    public String toString() {
        return "HealthService INFO {" + "Name of the Health Service : " + hsName + ", List of Patients : " + patlist + ", List of MedicalFacility : " + mflist + '}';
    }
    
}
