/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sophia
 */
public class MgrMember {
    public static ArrayList<Members> memList = new ArrayList<Members>();
    
    public void registMember() throws InterruptedException {
        Members mem = new Members();		
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Member's Id:");
        String memId = sc.nextLine();
        char exsited = 'N';
        for(int i=0;i< MgrMember.memList.size();i++){
            if (memId.equals(MgrMember.memList.get(i).getmId())){
                exsited = 'Y';                                
                System.out.println("Duplicate Member's Id!! re-enter:");
                break;
            } //end if
        }//end for

        if (exsited =='N'){  //if new member
            mem.setmId(memId);		

            System.out.println("Please enter Member's Password :");
            String pwd = sc.nextLine();
            mem.setmPwd(pwd);

            System.out.println("Please enter Member's name :");
            String name = sc.nextLine();
            mem.setmName(name);

            System.out.println("Please enter Member' email:");
            String email = sc.nextLine();
            mem.setmEail(email);

            System.out.println("Please enter Member' cellphone number:");
            String telno = sc.nextLine();
            mem.setmTelno(telno);

            System.out.println("Please enter Member' age:");
            String age = sc.nextLine();
            mem.setmAge(age);

            LocalDate  now = LocalDate.now();
            mem.setmRegDate(now.toString());		

            //preview Member info
            System.out.println("Member's Id : " + mem.getmId());
            System.out.println("Member's Pwd : " + mem.getmId());
            System.out.println("Member's Name : " + mem.getmName());
            System.out.println("Member's email : " + mem.getmEmail());
            System.out.println("Member's cell phone no : " + mem.getmTelno());
            System.out.println("Member's Age : " + mem.getmAge());
            System.out.println("Member's Regist Date : " + mem.getmRegDate());        

            System.out.println("Would you like to register this member? y or n?");
            String regYN = sc.nextLine();		
            if (regYN.equalsIgnoreCase("y")){
                    MgrMember.memList.add(mem);
                    System.out.println("Success Registration !!!");	
            }else{
                    System.out.println("Cancel Registration !!!");	
            }
        }
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doMemberMenu();            	
    }



    public void totalMemberList() throws InterruptedException{		
        char exsited = 'N';
        System.out.println(">>>>>>>                        Member List of this Library                  <<<<<<<");
        System.out.println("========================================================================================================================");
        System.out.printf("%15s |","Id ");		
        System.out.printf("%15s |","Pwd");
        System.out.printf("%15s |","Name");
        System.out.printf("%15s |","email");
        System.out.printf("%20s |","cell phone no");
        System.out.printf("%15s |","Age");
        System.out.printf("%15s |%n","Regist Date");   
        System.out.println("========================================================================================================================");
        for (int i = 0; i < MgrBook.bList.size(); i++) {			             
               System.out.printf("%15s |",MgrMember.memList.get(i).getmId());
               System.out.printf("%15s |",  MgrMember.memList.get(i).getmPwd());
               System.out.printf("%15s |", MgrMember.memList.get(i).getmName());
               System.out.printf("%15s |", MgrMember.memList.get(i).getmEmail());
               System.out.printf("%20s |", MgrMember.memList.get(i).getmTelno());
               System.out.printf("%15s |", MgrMember.memList.get(i).getmAge());
               System.out.printf("%15s |%n",MgrMember.memList.get(i).getmRegDate());               
               System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
               exsited = 'Y';  
        } // end for        

        if (exsited =='N') {
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
            System.out.println("Member List : no data ");
            System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
        }		   
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doMemberMenu();    
    }

    public void searchMember() throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Member ID:");			
        String memid = sc.nextLine();
        System.out.println("Enter Member Password:");			
        String mempwd = sc.nextLine();

        char exsited = 'N';
        for (int i = 0; i < MgrMember.memList.size(); i++) {
            if (memid.equals(MgrMember.memList.get(i).getmId()) && mempwd.equals(MgrMember.memList.get(i).getmPwd())) {
                System.out.println("++++++++++++++++++++++++++++++++");
                System.out.println("Member's Id : " + MgrMember.memList.get(i).getmId());
                System.out.println("Member's Pwd : " + MgrMember.memList.get(i).getmPwd());
                System.out.println("Member's Name : " + MgrMember.memList.get(i).getmName());
                System.out.println("Member's email : " + MgrMember.memList.get(i).getmEmail());
                System.out.println("Member's Cellphone Number : " + MgrMember.memList.get(i).getmTelno());
                System.out.println("Member's Age : " + MgrMember.memList.get(i).getmAge());
                System.out.println("Member's Regist Date : " + MgrMember.memList.get(i).getmRegDate()); 
                System.out.println("++++++++++++++++++++++++++++++++\n");
                exsited = 'Y';    
                break;
            }
        } // end for
    if (exsited =='N') {
        System.out.println("This member does not exist. Please re-enter another memeber's id and memeber'spassword.\n\n");
    } 
    Thread.sleep(1000);
    Menus mn = new Menus();
    mn.doMemberMenu(); 
    }

    public void modifyMember() throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.println("To modify infomation, Enter Member ID:");			
        String memid = sc.nextLine();
        System.out.println("Enter Member Password:");			
        String mempwd = sc.nextLine();

        char exsited = 'N';

        for (int i = 0; i < MgrMember.memList.size(); i++) {
            if (memid.equals(MgrMember.memList.get(i).getmId()) && mempwd.equals(MgrMember.memList.get(i).getmPwd())) {  
                System.out.println("Please enter Member's name :");
                String name = sc.nextLine();
                MgrMember.memList.get(i).setmName(name);


                System.out.println("Please enter Member' email:");
                String email = sc.nextLine();
                MgrMember.memList.get(i).setmEail(email);

                System.out.println("Please enter Member' cellphone number:");
                String telno = sc.nextLine();
                MgrMember.memList.get(i).setmTelno(telno);

                System.out.println("Please enter Member' age:");
                String age = sc.nextLine();
                MgrMember.memList.get(i).setmAge(age);

                System.out.println("Modify Successfully "); 
                exsited = 'Y';                      
                break;
            }
        } // end for
        if (exsited =='N') { 
             System.out.println("This member does not exist. Please re-enter another memeber's id and memeber'spassword.\n\n");
         } 
         Thread.sleep(1000);
         Menus mn = new Menus();
         mn.doMemberMenu();                
    }

    public void deleteMember() throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.println("To modify infomation, Enter Member ID:");			
        String memid = sc.nextLine();
        System.out.println("Enter Member Password:");			
        String mempwd = sc.nextLine();
        char exsited = 'N';
        for (int i = 0; i < MgrMember.memList.size(); i++) {
            if (memid.equals(MgrMember.memList.get(i).getmId()) && mempwd.equals(MgrMember.memList.get(i).getmPwd())) { 
                MgrMember.memList.remove(i);                    
                System.out.println("Delete Successfully");                
                exsited = 'Y';  
                break;
            }
        } // end for
        if (exsited =='N') {
            System.out.println("This member does not exist. Please re-enter another memeber's id and memeber'spassword.\n\n");
        }
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doMemberMenu(); 
    }

    public void initMembers() {
        // TODO Auto-generated constructor stub
        //create test data (initiallize Members.memList)
        MgrMember.memList.clear();
        for (int i=0;i<3;i++){
            MgrMember.memList.add(new Members("id"+i,"name"+i, "email" + i, "01111111"+i,"3"+i));
        }
    }
}
