/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;
/**
 *
 * @author Sophia
 */
public class Books {	
    private String bNo;
    private String bTitle;
    private String bAuthor;
    private String bGenre;
    private boolean bCheckOutYn; 

    public Books() {
        // TODO Auto-generated constructor stub        
    }
    
    public Books(String no, String title,String author,String gener) {
        // TODO Auto-generated constructor stub        
        this.bNo = no;
        this.bTitle = title;
        this.bAuthor = author;
        this.bGenre = gener;
        this.bCheckOutYn = true;
    }
   
    //getter
    public String getbNo(){
            return bNo;
    }

    public String getbTitle(){
            return bTitle;
    }

    public String getbAuthor(){
            return bAuthor;
    }

    public String getbGenre(){
            return bGenre;
    }

    public boolean getbCheckOutYn(){
            return bCheckOutYn;
    }


    //setter	
    public void setbNo(String no){
            this.bNo = no;
    }

    public void setbTitle(String title){
            this.bTitle = title;
    }

    public void setbAuthor(String author){
            this.bAuthor = author;
    }


    public void setbGenre(String genre){
            this.bGenre = genre;
    }

    public void setbCheckOutYn(boolean chkoutyn){
            this.bCheckOutYn = chkoutyn;
    }	

    @Override
    public String toString(){
        return "Book's No: " + bNo +
                ", Ttitle: " + bTitle +
                ", Author : " + bAuthor +
                ", Gener : " + bGenre +
                ", BarrowAble: " + bCheckOutYn;
    }
    
    
    
    
    
}
