/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;
import java.util.Scanner;
/**
 *
 * @author Sophia
 */
public class Menus {
      
    public Menus() {
            // TODO Auto-generated constructor stub
    }
	
	// show Top Menu
    public void doTopMenu() throws InterruptedException{	
        System.out.println("********************** Welcom to the Gumin Library **********************");
	System.out.println("                                TOP MENU                                 ");
	System.out.println("[1]Book Management\t[2]Member Management\t[3]Check-In/Check-Out a Book\t[0]exit\n");
	System.out.println("                              choose a menu                                ");
	System.out.println("**************************************************************************\n");
	
        Scanner sc = new Scanner(System.in);
        String tMenuNo = sc.nextLine();
       		
        switch(tMenuNo){
            case("1"):
                this.doBookMenu();		        	
                break;				
            case("2"):
                this.doMemberMenu();
                break;
            case("3"):
                this.doCheckMenu();
                break;						
            case("0"):
                System.out.println("***** Good Bye!! See You Again *****\n\n");
                sc.close();
                System.exit(0);
                break;
            default:
                System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
                this.doTopMenu();
                break;
        }			

    }
	
	//show Book Management Menu
    public void doBookMenu() throws InterruptedException{
        System.out.println("**************************** Book Management MENU ****************************");
	System.out.println("[11]Regist Book\t[12]Total BookLists\t[13]Search a Book\t[14]Modify a Book\t[15]Delete a Book\t[99]goto Top menu\n");
	System.out.println("                                choose a menu                                    ");
	System.out.println("**********************************************************************************\n");	
        MgrBook mbk = new MgrBook();
        
        Scanner sc = new Scanner(System.in);
	String bookMenuNo = sc.nextLine();
			
	switch(bookMenuNo){
            case("11"):
                mbk.registBook();
                break;				
            case("12"):
                mbk.totalBookList();
                break;
            case("13"):
                mbk.searchBook();
                break;
            case("14"):
                mbk.modifyBook();
                break;
            case("15"):
                mbk.deleteBook();
                break;				
            case("99"):
                System.out.println(">>>>  Go to Top Menu  <<<<\n\n");
                this.doTopMenu();				
                break;
            default:
                System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
                this.doBookMenu();
                break;
        }	
    }
	
    //show Member Management Menu
    
    public void doMemberMenu() throws InterruptedException{		         
        System.out.println("===============================  Member Management MENU ===============================");
        System.out.println("[21]Regist member\t[22]Total Member Info\t[23]Search a member\t[24]Modify a member\t[25]Delete a member\t[99]goto Top menu\n");
        System.out.println("                                  choose a menu                                      ");
        System.out.println("=======================================================================================\n");
        
        Scanner sc = new Scanner(System.in);
        String memMenuNo = sc.nextLine();
        MgrMember mmb = new MgrMember();  
        
        switch(memMenuNo){
            case("21"):
                mmb.registMember();
                break;				
            case("22"):
                mmb.totalMemberList();
                break;
            case("23"):
                mmb.searchMember();
                break;
            case("24"):
                mmb.modifyMember();
                break;
            case("25"):
                mmb.deleteMember();
                break;				
            case("99"):
                System.out.println(">>>>  Go to Top Menu  <<<<\n\n");
                this.doTopMenu();
                break;
            default:
                System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
                this.doMemberMenu();
                break;
        }			

    }	

    //show CheckIn/Out Management Menu
   
    public void doCheckMenu() throws InterruptedException{	
        System.out.println("====================== Check-Out/In Management MENU =======================");
        System.out.println("[31]Check Out a Book\t[32]Check in a Book\t[33]Borrowd List \t[99]goto Top menu\n");
        System.out.println("                          choose a menu                              ");
        System.out.println("===========================================================================\n");

        Scanner sc = new Scanner(System.in);
        String ckbMenuNo = sc.nextLine();
        MgrCheckBook mckb = new MgrCheckBook();
        switch(ckbMenuNo){
            case("31"):
                mckb.checkOutBook();
                break;				
            case("32"):
                mckb.checkInBook();
                break;
            case("33"):
                mckb.borrowList();
                break;							
            case("99"):
               System.out.println(" >>>>  Go to Top Menu  <<<<\n\n");
               this.doTopMenu();
                break;
            default:
                System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
                this.doCheckMenu();
                break;
        }			
        
    }
}
