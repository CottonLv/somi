/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sophia
 */
public class MgrCheckBook {
    public final int HOLD_PERIOD = 7;
    public final int FINES_PER_DAY = 20;
    
    public static ArrayList<CheckBook> ckbList = new ArrayList<CheckBook>();
    
     //check out
    public void checkOutBook() throws InterruptedException {
        int bcnt = 0;
        int mcnt = 0;
        CheckBook ckb = new CheckBook();
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter book number:");
        String bookno = sc.nextLine();
        System.out.println("Enter Member ID:");			
        String memid = sc.nextLine();
        System.out.println("Enter Member Password:");			
        String mempwd = sc.nextLine();

        //verify book info 
        for(int i=0;i<MgrBook.bList.size();i++){
            if (bookno.equals(MgrBook.bList.get(i).getbNo())){
                    bcnt++;
                    ckb.setbNo(bookno);
                    ckb.setbGenre(MgrBook.bList.get(i).getbGenre());
                    //update book status
                    MgrBook mb = new MgrBook();
                    mb.changeStat(bookno, false);
                    break;
            } //end i
        }//end for

        //verify member info
        for(int i=0;i<MgrMember.memList.size();i++){
            if (memid.equals(MgrMember.memList.get(i).getmId()) && mempwd.equals(MgrMember.memList.get(i).getmPwd())){
                    mcnt++;
                    ckb.setmId(memid);
                    break;
            } //end if
        }//end for		

        if (bcnt== 0 || mcnt == 0){
            System.out.println("Wrong !!. Please re-enter the book number/Id/Password\n\n");
        }else{
            //check in process
            ckb.setckType("check-out");
            LocalDate now = LocalDate.now();
            ckb.setckOutDate(now.toString());
            ckb.setckInDate("-");
            MgrCheckBook.ckbList.add(ckb);
            System.out.println("Successfully Check-out this Book \n\n");
        }
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doCheckMenu();
    }

	//check in
	public void checkInBook() throws InterruptedException {
            int bcnt = 0;
            int mcnt = 0;
            
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter book number:");
            String bookno = sc.nextLine();
            System.out.println("Enter Member ID:");			
            String memid = sc.nextLine();
            System.out.println("Enter Member Password:");			
            String mempwd = sc.nextLine();

            for(int i=0;i<MgrBook.bList.size();i++){
                if (bookno.equals(MgrBook.bList.get(i).getbNo())){
                        bcnt++;
                        break;
                } //end if
            }//end for

            for(int i=0;i<MgrMember.memList.size();i++){
                if (memid.equals(MgrMember.memList.get(i).getmId()) && mempwd.equals(MgrMember.memList.get(i).getmPwd())){
                        mcnt++;				
                        break;
                } //end if
            }//end for


            if (bcnt== 0 || mcnt == 0){
                System.out.println("Wrong !!. Please re-enter the book number/Id/Password\n\n");
            }else{
                //check out process
                LocalDate  now = LocalDate.now();
                for(int i=0;i<MgrCheckBook.ckbList.size();i++){
                    if (bookno.equals(MgrCheckBook.ckbList.get(i).getbNo())){
                        //compute diff day (day1, day2)
                        String day1 = MgrCheckBook.ckbList.get(i).getckOutDate();
                        String day2 = "2023-11-20"; //now.toString();
                        Period days = Period.between(LocalDate.parse(day1), LocalDate.parse(day2));
                        int dayCnt = days.getDays();
                        MgrCheckBook.ckbList.get(i).setckType("check-in");
                        MgrCheckBook.ckbList.get(i).setckInDate(day2);
                        MgrCheckBook.ckbList.get(i).setholdDays(dayCnt);

                        //compute Late Fines
                        if (days.getDays() > this.HOLD_PERIOD){
                                int price = (days.getDays() - this.HOLD_PERIOD) * this.FINES_PER_DAY;
                                MgrCheckBook.ckbList.get(i).setckFines(price);
                        }
                        //update book status
                        MgrBook mb = new MgrBook();
                        mb.changeStat(bookno, true);
                        System.out.println("Successfully Check-In this Book \n\n");
                        break;
                    } //end if
                }//end for		
            }
            Thread.sleep(1000);
            Menus mn = new Menus();
            mn.doCheckMenu();
	}	
	
	//display borrowed lists of books
	public void borrowList() throws InterruptedException {
             char exsited = 'N';
            System.out.println(">>>>>>                               borrowed lists of books                    <<<<<<");
            System.out.println("========================================================================================================================");
            System.out.printf("%10s |","Book No");		
            System.out.printf("%10s |","Book Gener");
            System.out.printf("%10s |","Mem Id");
            System.out.printf("%10s |","Type");
            System.out.printf("%15s |","CheckOut Date");
            System.out.printf("%15s |","CheckIn Date");
            System.out.printf("%-10s |","Holded Days");
            System.out.printf("%-10s |%n","Fines Amt");
            System.out.println("========================================================================================================================");
            for (int i = 0; i < MgrCheckBook.ckbList.size(); i++) {			
                   System.out.printf("%10s |",MgrCheckBook.ckbList.get(i).getbNo());
                   System.out.printf("%10s |",MgrCheckBook.ckbList.get(i).getbGenre());
                   System.out.printf("%10s |", MgrCheckBook.ckbList.get(i).getmId());
                   System.out.printf("%10s |",MgrCheckBook.ckbList.get(i).getckType());
                   System.out.printf("%15s |",MgrCheckBook.ckbList.get(i).getckOutDate());
                   System.out.printf("%15s |",MgrCheckBook.ckbList.get(i).getckInDate());
                   System.out.printf("%10d |",MgrCheckBook.ckbList.get(i).getholdDays());
                   System.out.printf("%10d |%n",MgrCheckBook.ckbList.get(i).getckFines());
                   System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
                   exsited = 'Y';
            } // end for
            
            if (exsited =='N') {
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
                System.out.println("borrowed lists of books : no data ");
                System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
            }	
            Thread.sleep(1000);
            Menus mn = new Menus();
            mn.doCheckMenu();
    }
}
