/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sophia
 */
public class MgrBook {
    public static ArrayList<Books> bList = new ArrayList<Books>();
     
    public void registBook() throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        Books bk = new Books();

        char exsited = 'N';
        System.out.println("Enter book number:");
        String bookno = sc.nextLine();

        for(int i=0;i<MgrBook.bList.size();i++){
            if (bookno.equals(MgrBook.bList.get(i).getbNo())){
                exsited = 'Y'; 
                System.out.println("Duplicate Book number!! re-enter:");
                break;
            } //end if
        }//end for

        if (exsited =='N'){
            bk.setbNo(bookno);			
            System.out.println("Please enter the book's title :");
            String booktitle = sc.nextLine();
            bk.setbTitle(booktitle);

            System.out.println("Please enter the author's name :");
            String bookauth = sc.nextLine();
            bk.setbAuthor(bookauth);

            System.out.println("Please enter the book's gener :");
            String bookgener = sc.nextLine();
            bk.setbGenre(bookgener);		
            bk.setbCheckOutYn(true);

            //preview the book info
            System.out.println("Book's Number : " + bk.getbNo());
            System.out.println("Book's Ttitle : " + bk.getbTitle());
            System.out.println("Book's Author : " + bk.getbAuthor());
            System.out.println("Book's Gener : " + bk.getbGenre());
            System.out.println("Can CheckOut : " + bk.getbCheckOutYn());

            System.out.println("Would you like to register this book? y or n?");
            String regYN = sc.nextLine();

            if (regYN.equalsIgnoreCase("y")){
                    MgrBook.bList.add(bk);
                    System.out.println("Success Registration !!!"); 
            }else{
                System.out.println("Cancel Registration !!!");   
            }
        }
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doBookMenu();
    }//end registBook()


    public void totalBookList() throws InterruptedException{
        char exsited = 'N';
        System.out.println("====================================================================================");
        System.out.printf("%15s |","Book No");		
        System.out.printf("%15s |","Book Title");
        System.out.printf("%15s |","Author Name");
        System.out.printf("%15s |","Book Genre");
        System.out.printf("%15s |%n","Barrowable");
        System.out.println("====================================================================================");
        for (int i = 0; i < MgrBook.bList.size(); i++) {			             
               System.out.printf("%15s |",MgrBook.bList.get(i).getbNo());
               System.out.printf("%15s |", MgrBook.bList.get(i).getbTitle());
               System.out.printf("%15s |", MgrBook.bList.get(i).getbAuthor());
               System.out.printf("%15s |", MgrBook.bList.get(i).getbGenre());
               System.out.printf("%15s |%n",MgrBook.bList.get(i).getbCheckOutYn());               
               System.out.println("---------------------------------------------------------------------------------------");
               exsited = 'Y';
        } // end for    
         if (exsited =='N') {
            System.out.println("---------------------------------------------------------------------------------------");
            System.out.println("Book List : no data ");
            System.out.println("---------------------------------------------------------------------------------------");
        }
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doBookMenu();
    }

    public void searchBook() throws InterruptedException{
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter book number");
        String bookno = sc.nextLine();
        char exsited = 'N';
        for (int i = 0; i < MgrBook.bList.size(); i++) {
            if (bookno.equals(MgrBook.bList.get(i).getbNo())) {
                System.out.println("++++++++++++++++++++++++++++++++");
                System.out.println("Book's Number : " + MgrBook.bList.get(i).getbNo());
                System.out.println("Book's Ttitle : " + MgrBook.bList.get(i).getbTitle());
                System.out.println("Book's Author : " + MgrBook.bList.get(i).getbAuthor());
                System.out.println("Book's Author : " + MgrBook.bList.get(i).getbGenre());
                System.out.println("Can CheckOut : " + MgrBook.bList.get(i).getbCheckOutYn());
                System.out.println("++++++++++++++++++++++++++++++++\n");
                exsited = 'Y';
                break;
            }
        } // end for
        if (exsited == 'N') {
            System.out.println("This book does not exist. Please re-enter the book number.");
        } 
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doBookMenu();   //goto Top menu        
    }

    public void modifyBook() throws InterruptedException{
        Scanner sc = new Scanner(System.in);
        
        System.out.println("To modify infomation, Enter book number:");
        String bookno = sc.nextLine();
        char exsited = 'N';
        for (int i = 0; i < MgrBook.bList.size(); i++) {
            if (bookno.equals(MgrBook.bList.get(i).getbNo())) {                	
                System.out.println("Please enter a book title :");
                String booktitle = sc.nextLine();
                MgrBook.bList.get(i).setbTitle(booktitle);

                System.out.println("Please enter the author's name :");
                String bookauth = sc.nextLine();
                MgrBook.bList.get(i).setbAuthor(bookauth);

                System.out.println("Please enter a book gener :");
                String bookgener = sc.nextLine();
                MgrBook.bList.get(i).setbGenre(bookgener);  	

                exsited = 'Y';
                System.out.println("Modify Successfully ");
                break;
            }
        } // end for
        if (exsited == 'N') {
            System.out.println("This book does not exist. Please re-enter the book number.");
        } 
        
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doBookMenu();   //goto Top menu  
    }

    public void deleteBook() throws InterruptedException{
        Scanner sc = new Scanner(System.in);

        System.out.println("To delete infomation, Enter book number:");
        String bookno = sc.nextLine();
        char exsited = 'N';
        for (int i = 0; i < MgrBook.bList.size(); i++) {
            if (bookno.equals(MgrBook.bList.get(i).getbNo())) {
                MgrBook.bList.remove(i);
                exsited = 'Y';
                System.out.println("Delete Successfully");
                break;
            }
        } // end for
        if (exsited == 'N') {
            System.out.println("This book does not exist. Please re-enter the book number.");
        } 
        Thread.sleep(1000);
        Menus mn = new Menus();
        mn.doBookMenu();   //goto Top menu  
    }
    
    public void changeStat(String bno,boolean stat) throws InterruptedException{
        for (int i = 0; i < MgrBook.bList.size(); i++) {
            if (bno.equals(MgrBook.bList.get(i).getbNo())) {
                MgrBook.bList.get(i).setbCheckOutYn(stat);                
                System.out.println("Successfully Change Barrowasble status ");
                break;
            }
        } // end for
    }
    
    public void initBooks() {
        // TODO Auto-generated constructor stub
         //create test data (initiallize BooksbList)
        MgrBook.bList.clear();
        for (int i=0;i<3;i++){
            MgrBook.bList.add(new Books("bk"+i,"tittle"+i, "autho" + i, "gener"+i));
       }
    }   
}
