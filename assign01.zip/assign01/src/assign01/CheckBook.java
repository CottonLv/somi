/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;

/**
 *
 * @author Sophia
 */
public class CheckBook {
    
    private String mId;
    private String bNo;
    private String bGenre;	
    private String ckType;
    private String ckOutDate;
    private String ckInDate;
    private int holdDays = 0;
    private int ckFines = 0;   

    public CheckBook() {
            // TODO Auto-generated constructor stub
    }

    //getter
    public String getmId(){
        return mId;
    }

    public String getbNo(){
        return bNo;
    }

    public String getbGenre(){
        return bGenre;
    }

    public String getckType(){
        return ckType;
    }

    public String getckOutDate(){
        return ckOutDate;
    }
    
    public String getckInDate(){
        return ckInDate;
    }
    
    public int getholdDays(){
        return holdDays;
    }

    public int getckFines(){
        return ckFines;
    }

    //setter	
    public void setmId(String id){
        this.mId = id;
    }

    public void setbNo(String no){
        this.bNo = no;
    }	

    public void setbGenre(String genre){
        this.bGenre = genre;
    }

    public void setckType(String type){
        this.ckType = type;
    }

    public void setckInDate(String date){
        this.ckInDate = date;
    }

    public void setckOutDate(String date){
        this.ckOutDate = date;
    }

    public void setholdDays(int days){
        this.holdDays = days;
    }	
    public void setckFines(int price){
        this.ckFines = price;
    }   
}
