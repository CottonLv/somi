/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;

import java.time.LocalDate;

/**
 *
 * @author Sophia
 */
public class Members {
    private String mId;
    private String mPwd;
    private String mName;
    private String mEmail;
    private String mTelno;
    private String mAge;
    private String mRegDate;
  
    public Members() {
            // TODO Auto-generated constructor stub
    }
        
    public Members(String id,String name, String email, String telno,String age) {
            // TODO Auto-generated constructor stub
        LocalDate  now = LocalDate.now();

        this.mId = id;
        this.mPwd = "0000";
        this.mName = name;
        this.mEmail = email;
        this.mTelno = telno;
        this.mAge = age;
        this.mRegDate = now.toString();        
    }
	
	
    //getter this class member variables
    public String getmId(){
        return mId;
    }

    public String getmPwd(){
        return mPwd;
    }

    public String getmName(){
        return mName;
    }

    public String getmEmail(){
        return mEmail;
    }

    public String getmAge(){
        return mAge;
    }

    public String getmTelno(){
        return mTelno;
    }

    public String getmRegDate(){
        return mRegDate;
    }    
   

    //setter this class member variables	
    public void setmId(String id){
        this.mId = id;
    }

    public void setmPwd(String pwd){
        this.mPwd = pwd;
    }

    public void setmName(String name){
        this.mName = name;
    }


    public void setmEail(String mail){
        this.mEmail = mail;
    }

    public void setmTelno(String telno){
        this.mTelno = telno;
    }

    public void setmAge(String age){
        this.mAge = age;
    }

    public void setmRegDate(String regdate){
        this.mRegDate = regdate;
    }    
}
