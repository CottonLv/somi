/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assign01;

/**
 *
 * @author Sophia
 */
public class MainLibray {
     // TODO code application logic here
   public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        //to test, initialize Books/Members 
        MgrBook mbk = new MgrBook();
        mbk.initBooks();
        MgrMember mmb = new MgrMember();
        mmb.initMembers();
        
        Menus menu = new Menus();
        menu.doTopMenu();	 
    }
}
