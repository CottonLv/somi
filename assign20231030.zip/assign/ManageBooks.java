package assign;

import java.util.Scanner;

public class ManageBooks {
	
	Scanner sc = new Scanner(System.in);
	public ManageBooks() {
		// TODO Auto-generated constructor stub
	}
	
	public void registBook() throws InterruptedException {
		Books bk = new Books();

		while(true){		
			int cnt = 0;
			System.out.println("Enter book number:");
			String bookno = sc.nextLine();
			
			for(int i=0;i<Books.bList.size();i++){
				if (bookno.equals(Books.bList.get(i).getbNo())){
					cnt++;
					System.out.println("Duplicate Book number!! re-enter:");
					break;
				} //end if
			}//end for
			
			if (cnt==0){
				bk.setbNo(bookno);				
			}
					
			System.out.println("Please enter a book title :");
			String booktitle = sc.nextLine();
			bk.setbTitle(booktitle);
			
			System.out.println("Please enter the author's name :");
			String bookauth = sc.nextLine();
			bk.setbAuthor(bookauth);
				
			System.out.println("Please enter a book gener :");
			String bookgener = sc.nextLine();
			bk.setbGenre(bookgener);
			
			bk.setbLentYn(true);
			
			Thread.sleep(1000);
			
			//
			System.out.println("Book's Number : " + bk.getbNo());
            System.out.println("Book's Ttitle : " + bk.getbTitle());
            System.out.println("Book's Author : " + bk.getbAuthor());
            System.out.println("Book's Gener : " + bk.getbGenre());
            System.out.println("Can Lent Y/N : " + bk.getbLentYn());
            
            System.out.println("Would you like to register this book? y or n?");
            String regYN = sc.nextLine();
			
            if (regYN.equalsIgnoreCase("y")){
            	Books.bList.add(bk);
            	System.out.println("Success Registration !!!");
            	Menus mn = new Menus();
            	mn.doBookMenu();
            	break;
            }else{
            	System.out.println("Re-Enter Book");
            	continue;
            }
            
		}//end while
		Thread.sleep(1000);
	}//end registBook()
	
	public void totalBookList(){

		 for (int i = 0; i < Books.bList.size(); i++) {
             System.out.println("++++++++++++++++++++++++++++++++");
             System.out.println("Book's Number : " + Books.bList.get(i).getbNo());
             System.out.println("Book's Ttitle : " + Books.bList.get(i).getbTitle());
             System.out.println("Book's Author  : " + Books.bList.get(i).getbAuthor());
             System.out.println("Book's Gener  : " + Books.bList.get(i).getbGenre());
             System.out.println("Can Lent Y/N : " + Books.bList.get(i).getbLentYn());
             System.out.println("++++++++++++++++++++++++++++++++\n");

         } // end for
	}
	
	public void searchBook() throws InterruptedException{
		while(true){
			System.out.println("Enter book number");
			String bookno = sc.nextLine();
			int cnt = 0;
            for (int i = 0; i < Books.bList.size(); i++) {
                if (bookno.equals(Books.bList.get(i).getbNo())) {
                	System.out.println("++++++++++++++++++++++++++++++++");
                    System.out.println("Book's Number : " + Books.bList.get(i).getbNo());
                    System.out.println("Book's Ttitle : " + Books.bList.get(i).getbTitle());
                    System.out.println("Book's Author : " + Books.bList.get(i).getbAuthor());
                    System.out.println("Book's Author : " + Books.bList.get(i).getbGenre());
                    System.out.println("Can Lent Y/N : " + Books.bList.get(i).getbLentYn());
                    System.out.println("++++++++++++++++++++++++++++++++\n");
                    cnt++;
                    break;
                }
            } // end for
            if (cnt == 0) {
                System.out.println("This book does not exist. Please re-enter the book number.");
            } else {
            	Menus mn = new Menus();
            	mn.doBookMenu();
                break;// ��������
            }
		}
	}
	
	public void modifyBook(){
		
		while (true) {
			System.out.println("To modify infomation, Enter book number:");
			String bookno = sc.nextLine();
            int cnt = 0;
            for (int i = 0; i < Books.bList.size(); i++) {
                if (bookno.equals(Books.bList.get(i).getbNo())) {                	

        			System.out.println("Please enter a book title :");
        			String booktitle = sc.nextLine();
        			Books.bList.get(i).setbTitle(booktitle);
        			
        			System.out.println("Please enter the author's name :");
        			String bookauth = sc.nextLine();
        			Books.bList.get(i).setbAuthor(bookauth);
        				
        			System.out.println("Please enter a book gener :");
        			String bookgener = sc.nextLine();
        			Books.bList.get(i).setbGenre(bookgener);  	
                	
                    cnt++;
                    System.out.println("Modify Successfully ");
                    break;
                }
            } // end for
            if (cnt == 0) {
                System.out.println("This book does not exist. Please re-enter the book number.");
            } else {
                break;
            }
        } // end while
	}
	
	public void deleteBook(){
		Books bk = new Books();
		 while (true) {
			System.out.println("To delete infomation, Enter book number:");
			String bookno = sc.nextLine();
	        int cnt = 0;
	            for (int i = 0; i < Books.bList.size(); i++) {
	                if (bookno.equals(bk.bList.get(i).getbNo())) {
	                	Books.bList.remove(i);
	                    cnt++;
	                    System.out.println("Delete Successfully");
	                    break;
	                }
	            } // end for
	            if (cnt == 0) {
	                System.out.println("This book does not exist. Please re-enter the book number.");
	            } else {
	                break;
	            }
	        } // end while
	}
	
	public void checkoutBook(){

		while (true) {
			System.out.println("To check out a book, Enter book number:");
			String bookno = sc.nextLine();
            int cnt = 0;
            for (int i = 0; i < Books.bList.size(); i++) {
                if (bookno.equals(Books.bList.get(i).getbNo())) {
                    cnt++;
                    boolean bStatus = Books.bList.get(i).getbLentYn();
 
                    if (bStatus) {
                    	Books.bList.get(i).setbLentYn(false);                        
                        System.out.println("The book checked out successfully.");
                    } else {                    	
                        System.out.println("The book is already on loan.");
                    }
                    
                    break;
                }
            } // end for
            if (cnt == 0) {
                System.out.println("This book does not exist. Please re-enter the book number.");
            } else {
                break;// ��������
            }
        } // end while
	}
	
	public void checkinBook(){
		
		while (true) {
			System.out.println("To checkin a book, Enter book number:");
			String bookno = sc.nextLine();
            int cnt = 0;
            for (int i = 0; i < Books.bList.size(); i++) {
                if (bookno.equals(Books.bList.get(i).getbNo())) {
                		cnt++;
                        Books.bList.get(i).setbLentYn(true);                        
                        System.out.println("The book checked in successfully !!.");                   
                    }                    
                    break;           
            } // end for
            if (cnt == 0) {
                System.out.println("This book does not exist. Please re-enter the book number.");
            } else {
                break;// ��������
            }
        } // end while
	}
}
