package assign;

public class LibaryMain {
     
	  public static void main(String[] args) throws InterruptedException {
		
		  Menus menu = new Menus();
		  menu.doTopMenu();
	  }
}
