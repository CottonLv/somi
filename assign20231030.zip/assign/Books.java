package assign;

import java.util.ArrayList;
import java.util.Scanner;

public class Books {
	
	
	private String bNo;
	private String bTitle;
	private String bAuthor;
	private String bGenre;
	private boolean bLentYn;
	

	public static ArrayList<Books> bList = new ArrayList<Books>();
	
	
	public Books() {
		// TODO Auto-generated constructor stub
	}
	
	//getter
	public String getbNo(){
		return bNo;
	}
	
	public String getbTitle(){
		return bTitle;
	}

	public String getbAuthor(){
		return bAuthor;
	}

	public String getbGenre(){
		return bGenre;
	}
	
	public boolean getbLentYn(){
		return bLentYn;
	}
	
	
	//setter	
	public void setbNo(String no){
		this.bNo = no;
	}
	
	public void setbTitle(String title){
		this.bTitle = title;
	}
	
	public void setbAuthor(String author){
		this.bAuthor = author;
	}
	
	
	public void setbGenre(String genre){
		this.bGenre = genre;
	}
	
	public void setbLentYn(boolean lentyn){
		this.bLentYn = lentyn;
	}
	
	
	
}
