package assign;

import java.util.ArrayList;
import java.util.Scanner;

public class Members {
	Scanner sc = new Scanner(System.in);
	private String mId;
	private String mPwd;
	private String mName;
	private String mEmail;
	private String mTelno;
	private String mAge;
	private String mRegDate;
	private int mLateFee = 0;
	/*	
    private String mGener;
	private String mBkNo;
	private String mBkTitle;
	private String mCkinDate;
	private String mCkoutDate;
	private int mLateFee = 0;
	*/
	public static ArrayList<Members> memList = new ArrayList<Members>();
	
	public Members() {
		// TODO Auto-generated constructor stub
	}
	
	
	//getter
	public String getmId(){
		return mId;
	}
	
	public String getmPwd(){
		return mPwd;
	}

	public String getmName(){
		return mName;
	}
	
	public String getmEmail(){
		return mEmail;
	}
	
	public String getmAge(){
		return mAge;
	}
	
	public String getmTelno(){
		return mTelno;
	}
	
	public String getmRegDate(){
		return mRegDate;
	}
	
	//setter	
	public void setmId(String id){
		this.mId = id;
	}
	
	public void setmPwd(String pwd){
		this.mPwd = pwd;
	}
	
	public void setmName(String name){
		this.mName = name;
	}
	
	
	public void setmEail(String mail){
		this.mEmail = mail;
	}
	
	public void setmTelno(String telno){
		this.mTelno = telno;
	}
	
	public void setmAge(String age){
		this.mAge = age;
	}
	
	public void setmRegDate(String regdate){
		this.mRegDate = regdate;
	}	
	
}
