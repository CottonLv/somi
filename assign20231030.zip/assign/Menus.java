package assign;

import java.util.ArrayList;
import java.util.Scanner;

public class Menus {
	Scanner sc = new Scanner(System.in);
	public Menus() {
		// TODO Auto-generated constructor stub
	}
	
	// show Top Menu
	public void doTopMenu() throws InterruptedException{		
	  System.out.println("***** Welcom to the Gumin Library *****");
	  System.out.println("[1]Book Management\t[2]Member Management\t[3]Check-In/Check-Out a Book\t[0]exit");
	  System.out.println("***************************************\n");
	
		String tMenuNo = sc.nextLine();
		Menus sm = new Menus();
		while(true){			
			switch(tMenuNo){
				case("1"):
					sm.doBookMenu();		        	
					break;				
				case("2"):
					sm.doMemberMenu();
					break;
				case("3"):
					sm.doCheckMenu();
					break;						
				case("0"):
					System.out.println("***** Good Bye!! See You Again *****\n\n");
					sc.close();
					System.exit(0);
					break;
				default:
					System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
					break;
			}			
		}
	}
	
	//show Book Management Menu
	public void doBookMenu() throws InterruptedException{
		 System.out.println("======= Book Management ========");
		 System.out.println("[11]Regist Book\t[12]Total BookLists\t[13]Search a Book\t[14]Modify a Book\t[15]Delete a Book\t[99]go home");
		 System.out.println("================================\n");
		ManageBooks mgbk = new ManageBooks();
		String bookMenuNo = sc.nextLine();
			
			switch(bookMenuNo){
				case("11"):
					mgbk.registBook();
					break;				
				case("12"):
					mgbk.totalBookList();
					break;
				case("13"):
					mgbk.searchBook();
					break;
				case("14"):
					mgbk.modifyBook();
					break;
				case("15"):
					mgbk.deleteBook();
					break;				
				case("99"):
					Menus sm = new Menus();
					System.out.println("***** Go to Top Menu *****\n\n");
					sm.doTopMenu();				
					break;
				default:
					System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
					break;
			}			
		
	}
	
	//show Member Management Menu
	public void doMemberMenu() throws InterruptedException{
		
		ManageMembers mgmb = new ManageMembers();
		while(true){
			System.out.println("======= Member Management ========");
			System.out.println("[21]Regist member\t[22]Total Member Info\t[23]Search a member\t[24]Modify a member\t[25]Delete a member\t[99]go home");
			System.out.println("==================================\n");
			
			String memMenuNo = sc.nextLine();
				
			switch(memMenuNo){
				case("21"):
					mgmb.registMember();
					break;				
				case("22"):
					mgmb.totalMemberList();
					break;
				case("23"):
					mgmb.searchMember();
					break;
				case("24"):
					mgmb.modifyMember();
					break;
				case("25"):
					mgmb.deleteMember();
					break;				
				case("99"):
					Menus sm = new Menus();
					System.out.println("***** Go to Top Menu *****\n\n");
					sm.doTopMenu();
					break;
				default:
					System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
					break;
			}			
		}
	}	
	
	//show CheckIn/Out Management Menu
	public void doCheckMenu() throws InterruptedException{			
		ManageCheckBook mckb = new ManageCheckBook();
		
		while(true){			
			System.out.println("======= Check-Out/In Management =======");
			System.out.println("[31]Check Out a Book\t[32]Check in a Book\t[33]Borrowd List \t[99]go home");
			System.out.println("=======================================\n");
			String ckbMenuNo = sc.nextLine();
			switch(ckbMenuNo){
				case("31"):
					mckb.checkOutBook();
					break;				
				case("32"):
					mckb.checkInBook();
					break;
				case("33"):
					mckb.borrowList();
					break;							
				case("99"):
					Menus sm = new Menus();
					System.out.println(" Go to Top Menu!! \n\n");
					sm.doTopMenu();
					break;
				default:
					System.out.println("Your Entered wrong Menu!! Enter Again\n\n");
					break;
			}			
		}
	}	
}
